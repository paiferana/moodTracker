package com.example.virtual_album

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
